import os
import customtkinter
import subprocess


def terminal():
    def run_command():
        command = command_entry.get()
        try:
            # 
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            output = result.stdout
            error = result.stderr
            
            # boxu günceller
            terminal_output.configure(state='normal')
            terminal_output.delete(1.0, 'end')  
            
           
            if output:
                terminal_output.insert('end', "Output:\n" + output + '\n')
            if error:
                terminal_output.insert('end', "Error:\n" + error + '\n')
            
            terminal_output.configure(state='disabled')
        except Exception as e:
            terminal_output.configure(state='normal')
            terminal_output.delete(1.0, 'end')  
            terminal_output.insert('end', f"Exception: {e}")
            terminal_output.configure(state='disabled')

    com = customtkinter.CTkToplevel()
    com.title("Command Panel")
    com.geometry("600x400")

    # Command entry si
    command_entry = customtkinter.CTkEntry(com)
    command_entry.pack(padx=10, pady=5, fill='x')

    # Run button
    run_button = customtkinter.CTkButton(com, text="Run", command=run_command)
    run_button.pack(padx=10, pady=5)
    

    # output
    terminal_output = customtkinter.CTkTextbox(com, state='disabled')
    terminal_output.pack(padx=10, pady=5, fill='both', expand=True)

    com.mainloop()

# url yi kontrol eden function
def check_and_run_url():
    url = url_search.get()
    directory = r"C:\Users\ASUS\Desktop\project hack game\DARK NETWORK\URL"
    file_path = os.path.join(directory, url)

    if os.path.isfile(file_path):
        with open(file_path, 'r') as file:
            file_content = file.read().strip()
            if file_content:
                try:
                    exec(file_content)
                except Exception as e:
                    print(f"Could not execute the file content: {e}")
                    show_warning("File execution error")
    else:
        show_warning("File not found")

# hata guisi
def show_warning(message):
    warnings_label = customtkinter.CTkLabel(Darknetwork, text=message, text_color="red")
    warnings_label.pack()
    Darknetwork.update()  # Update the window to show the warning messages
    Darknetwork.after(4000, warnings_label.destroy)  # Destroy the warning after 4 seconds

# Main window
Darknetwork = customtkinter.CTk()
Darknetwork.title("DarkNetWork")
Darknetwork.geometry("800x600")
Darknetwork._set_appearance_mode("dark")

# GUI

# Terminal button
terminal_button = customtkinter.CTkButton(Darknetwork, text="Terminal", command=terminal, fg_color="Black", hover_color="White")
terminal_button.pack(side="top", anchor="nw", padx=10, pady=8)

# URL entry
url_search = customtkinter.CTkEntry(Darknetwork, text_color="green")
url_search.pack()

# Check URL button
check_url_button = customtkinter.CTkButton(Darknetwork, text="Check URL", command=check_and_run_url, fg_color="Green", hover_color="Blue")
check_url_button.pack(padx=10, pady=8)


connect = customtkinter.CTkButton(Darknetwork, text="Connect", command=None, hover_color="White", fg_color="Black")
connect.pack(side="top", anchor="sw", padx=10, pady=8)


# Main looper
Darknetwork.mainloop()
